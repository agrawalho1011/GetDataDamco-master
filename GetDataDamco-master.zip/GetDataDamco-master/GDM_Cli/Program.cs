﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace GDM_Cli
{
    class Program
    {
        static void Main(string[] args)
        {
            getdata();
        }
        //public static async Task getdataAsync()
        //{
        //     webClient = new WebClient();
        //    webClient.Proxy.Credentials = new NetworkCredential("u139289", "Opera@1982", "sharedservices");
        //    webClient.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");

        //    object p = await webClient.DownloadStringAsync(new Uri(@"https://ecu.statistics.eu.eculine.net/ECU.TNT/WebApi/api/event/GetAllShipmentInfoWeb?blReference=HOUAUADL3H3491"));
        //    Console.Write(json.ToString());
        //    System.IO.File.WriteAllText(Environment.CurrentDirectory + "\\GetData.json", json.ToString());
        //}

        public static void getdata()
        {

            var wProxy = new WebProxy()
            {
                Address = new Uri(@"http:\\10.38.193.47:8080"),
                BypassProxyOnLocal = false,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential("u139289", "Opera@1982", "sharedservices")
            };

            HttpClientHandler httpClientHandler = new HttpClientHandler()
            {
                Proxy = wProxy
            };

            HttpClient client = new HttpClient(httpClientHandler);
            System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            var response = client.GetAsync(@"https://ecu.statistics.eu.eculine.net/ECU.TNT/WebApi/api/event/GetAllShipmentInfoWeb?blReference=ECU00515291").Result;
            if(response.IsSuccessStatusCode == true)
            {
                var json = response.Content;
            }

        }
    }
}
