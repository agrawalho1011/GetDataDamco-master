﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GetDataDamco
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private async void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDailog = new OpenFileDialog();
            if (fileDailog.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = fileDailog.FileName;
                string[] inputData = System.IO.File.ReadAllLines(fileDailog.FileName);
                Getdata(inputData);
                MessageBox.Show("Download Successfull!");
            }
        }

        public void Getdata(string[] inputString)
        {

            DataTable dtOuput = new DataTable();
            dtOuput.Columns.Add("BLNumber");
            dtOuput.Columns.Add("Cargo");
            dtOuput.Columns.Add("Origin");
            dtOuput.Columns.Add("Destination");
            dtOuput.Columns.Add("DepContainerID");
            dtOuput.Columns.Add("DepVesselName");
            dtOuput.Columns.Add("ArrContainerID");
            dtOuput.Columns.Add("ArrVesselName");
            dtOuput.Columns.Add("PackageAmount");
            dtOuput.Columns.Add("PackageType");
            dtOuput.Columns.Add("Volume");
            dtOuput.Columns.Add("Weight");
            dtOuput.Columns.Add("BLReference");
            dtOuput.Columns.Add("Place of delivery");
            dtOuput.Columns.Add("Port of Discharge");
            dtOuput.Columns.Add("Place of Receipt");
            dtOuput.Columns.Add("Port of Loading");
            progressBar1.Maximum = inputString.Count();
            progressBar1.Value = 0;
            foreach (string s in inputString)
            {
                progressBar1.Value = progressBar1.Value + 1;
                try
                {
                    WebClient webClient = new WebClient();
                    webClient.Proxy.Credentials = new NetworkCredential(txtUsername.Text, txtPassword.Text, "sharedservices");
                    webClient.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
                    System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                    //var json = webClient.DownloadString(@"https://ecu.statistics.eu.eculine.net/ECU.TNT/WebApi/api/event/GetAllShipmentInfoWeb?blReference=" + s);
                    var json = webClient.DownloadString(@"https://tnt-api-v2.ecuworldwide.com/api/event/GetAllShipmentInfoWeb?blReference=" + s);
                    var jObject = JsonConvert.DeserializeObject<Object>(json);
                    DataRow drOuput = dtOuput.NewRow();
                    drOuput["BLNumber"] = s;
                    drOuput["Cargo"] = jObject.root.ShipmentDetails_MobileApp.shipingInformation.Cargo;
                    drOuput["Origin"] = jObject.root.ShipmentDetails_MobileApp.shipingInformation.Origin;
                    drOuput["Destination"] = jObject.root.ShipmentDetails_MobileApp.shipingInformation.Destination;
                    drOuput["DepContainerID"] = jObject.root.ShipmentDetails_MobileApp.shipingInformation.DepContainerID;
                    drOuput["DepVesselName"] = jObject.root.ShipmentDetails_MobileApp.shipingInformation.DepVesselName;
                    drOuput["ArrContainerID"] = jObject.root.ShipmentDetails_MobileApp.shipingInformation.ArrContainerID;
                    drOuput["ArrVesselName"] = jObject.root.ShipmentDetails_MobileApp.shipingInformation.ArrVesselName;
                    drOuput["PackageAmount"] = jObject.root.ShipingInformationElements.shipingInformation.PackageAmount;
                    drOuput["PackageType"] = jObject.root.ShipingInformationElements.shipingInformation.PackageType;
                    drOuput["Volume"] = jObject.root.ShipingInformationElements.shipingInformation.Volume;
                    drOuput["Weight"] = jObject.root.ShipingInformationElements.shipingInformation.Weight;
                    drOuput["BLReference"] = jObject.root.ShipingInformationElements.shipingInformation.BLReference;
                    foreach (var doc in jObject.root.RoutingElements.routing)
                    {
                        var routinginfo = JsonConvert.DeserializeObject<RoutingItems>(doc.ToString());
                        if (routinginfo.RoutingTypeID.Trim() == "PLOD")
                        {
                            drOuput["Place of delivery"] = routinginfo.LocationID;
                        }
                        else if (routinginfo.RoutingTypeID.Trim() == "POD")
                        {
                            drOuput["Port of Discharge"] = routinginfo.LocationID;
                        }
                        else if (routinginfo.RoutingTypeID.Trim() == "POR")
                        {
                            drOuput["Place of Receipt"] = routinginfo.LocationID;
                        }
                        else if (routinginfo.RoutingTypeID.Trim() == "POL")
                        {
                            drOuput["Port of Loading"] = routinginfo.LocationID;
                        }
                    }
                    foreach (var doc in jObject.root.EventElements.Event)
                    {
                        var eventItem = JsonConvert.DeserializeObject<EventItems>(doc.ToString());
                        bool isAvailable = false;
                        foreach (DataColumn dc in dtOuput.Columns)
                        {
                            if (dc.ColumnName == eventItem.EventTypeName)
                            {
                                isAvailable = true;
                            }
                        }
                        if (isAvailable == false)
                        {
                            dtOuput.Columns.Add(eventItem.EventTypeName);
                            dtOuput.Columns.Add(eventItem.EventTypeName + "_Location");
                            dtOuput.Columns.Add(eventItem.EventTypeName + "_Comments");
                            drOuput[eventItem.EventTypeName] = eventItem.EventDate;
                            drOuput[eventItem.EventTypeName + "_Location"] = eventItem.EventLocationID;
                            drOuput[eventItem.EventTypeName + "_Comments"] = eventItem.Comments;
                        }
                        else if (string.IsNullOrEmpty(drOuput[eventItem.EventTypeName].ToString()))
                        {
                            drOuput[eventItem.EventTypeName] = eventItem.EventDate;
                            drOuput[eventItem.EventTypeName + "_Location"] = eventItem.EventLocationID;
                            drOuput[eventItem.EventTypeName + "_Comments"] = drOuput[eventItem.EventTypeName + "_Comments"].ToString() + Environment.NewLine + eventItem.Comments;
                        }
                        else if (!string.IsNullOrEmpty(drOuput[eventItem.EventTypeName].ToString()))
                        {
                            drOuput[eventItem.EventTypeName] = drOuput[eventItem.EventTypeName].ToString() + Environment.NewLine + eventItem.EventDate;
                            drOuput[eventItem.EventTypeName + "_Location"] = eventItem.EventLocationID;
                            drOuput[eventItem.EventTypeName + "_Comments"] = drOuput[eventItem.EventTypeName + "_Comments"].ToString() + Environment.NewLine + eventItem.Comments;
                        }

                    }
                    dtOuput.Rows.Add(drOuput);
                }
                catch (Exception ex)
                {
                    if (!System.IO.File.Exists(Application.StartupPath + "\\ErrorList.csv"))
                    {
                        System.IO.File.WriteAllText(Application.StartupPath + "\\ErrorList.csv", s);
                    }
                    else
                    {
                        System.IO.File.AppendAllText(Application.StartupPath + "\\ErrorList.csv", Environment.NewLine + s);
                    }
                }
            }
            dtOuput.TableName = "OutputTable";
            dtOuput.WriteXml(Application.StartupPath + "\\Output" + DateTime.Now.ToString("ddMMyyhhmmss") + ".xls");
        }

    }
}



public struct Object
{
    public root root { get; set; }
}
public struct root
{
    public EventElements EventElements { get; set; }
    public RoutingElements RoutingElements { get; set; }
    public ShipingInformationElements ShipingInformationElements { get; set; }
    public JObject ShipingCustomers { get; set; }
    public ShipmentDetails_MobileApp ShipmentDetails_MobileApp { get; set; }
}

/// <summary>
/// EventElements
/// </summary>

public struct EventElements
{
    public JArray Event { get; set; }
}

public struct EventItems
{
    public string ID { get; set; }
    public string BLReference { get; set; }
    public DateTime EventDate { get; set; }
    public string EventTypeName { get; set; }
    public string EventLocationID { get; set; }
    public string Comments { get; set; }
}


public struct RoutingElements
{
    public JArray routing { get; set; }
}
public struct Routing
{
    public JArray Items { get; set; }
}
public struct RoutingItems
{
    public string EstimatedArrivalDate { get; set; }
    public string ID { get; set; }
    public string LocationID { get; set; }
    public string IsDeleted { get; set; }
    public string MessageID { get; set; }
    public string RoutingTypeID { get; set; }
    public string BLReference { get; set; }
    public string LocationName { get; set; }
    public string RouteTypeDesc { get; set; }
}

/// <summary>
/// ShipingInformationElements
/// </summary>

public struct ShipingInformationElements
{
    public ShipingInformation shipingInformation { get; set; }

}
public struct ShipingInformation
{
    public string ID { get; set; }
    public string MessageID { get; set; }
    public string PackageAmount { get; set; }
    public string PackageType { get; set; }
    public string Volume { get; set; }
    public string Weight { get; set; }
    public string BLReference { get; set; }
}
/// <summary>
/// ShipingCustomer Info
/// </summary>
public struct ShipingCustomers
{
    public JArray shipingCustomer { get; set; }

}
public struct ShipingCustomer
{
    public string ID { get; set; }
    public string MessageID { get; set; }
    public string BLReference { get; set; }
    public string TypeID { get; set; }
    public string CustomerID { get; set; }
    public string Name { get; set; }
    public string ISOCountryCode { get; set; }
    public string CreatedOn { get; set; }
}
/// <summary>
/// Shipmenet Details Mobile
/// </summary>
public struct ShipmentDetails_MobileApp
{
    public ShipingInformation1 shipingInformation { get; set; }
}
public struct ShipingInformation1
{
    public string Cargo { get; set; }
    public string Origin { get; set; }
    public string Destination { get; set; }
    public string DepContainerID { get; set; }
    public string DepVesselName { get; set; }
    public string ArrContainerID { get; set; }
    public string ArrVesselName { get; set; }
}
